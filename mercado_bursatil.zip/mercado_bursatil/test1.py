
from flask import Flask, render_template
import requests,json,threading,time,webbrowser,os
from bs4 import BeautifulSoup
from bokeh.plotting import figure, output_file,show




#Variables globales
aplicacion = Flask(__name__)
data_p = []
data_s = []
data_b = []
path_actual = os.getcwd()

#Clase que MAnipula Peticiones y contiene Metodo de visualizacion en construccion 
class data():
    data_d = {}
    data_d2 = {}
    
    #Metodo de peticion a tidex
    def req():
        #Metodo interno para visualizacion de datos en construccion
        def visualizacion2(valores,y,z):
            path_grafica = str(path_actual)+"\\templates\\graficado_2.html"
            print("_"*20)
            print(str(path_grafica))
            output_file(str(path_grafica))
            fig = figure()
            print(str(type(fig)))
            #print(str(help(figure)))
            #valores = valores
            x_vals = valores
            y_vals = y
            z_vals = z

            #help(fig)
            fig.line(x_vals,y_vals,line_width=2,line_color='blue')
            fig.line(x_vals,z_vals,line_width=2,line_color='red')
            show(fig)
        #tratamiento de peticion a https://api.tidex.com/api/3/ticker/eth_btc 
        resultado = requests.get('https://api.tidex.com/api/3/ticker/eth_btc')
        if resultado.status_code == 200:
            #parsing de datos
            obj_bs = BeautifulSoup(resultado.content,'html.parser')
            #debug de resultado de peticion
            #print(resultado.content.decode("utf-8") )
        #conversion de resultado a diccionario
        data_dict = dict(json.loads(resultado.content.decode("utf-8")))

        #tratamiento de peticion a https://api.tidex.com/api/3/ticker/ltc_btc
        resultado2 = requests.get('https://api.tidex.com/api/3/ticker/ltc_btc')
        if resultado2.status_code == 200:
            #parsing de datos
            obj_bs2 = BeautifulSoup(resultado2.content,'html.parser')
            #debug de resultado de peticion
            #print(resultado2.content.decode("utf-8") )
        #conversion de resultado a diccionario
        data_dict2 = dict(json.loads(resultado2.content.decode("utf-8")))
        print(str(data_dict2))

        #tratamiento de datos para retorno a peticion ajax
        data_niv1 = data_dict['eth_btc']
        data_2_niv1 = data_dict2['ltc_btc']
        data_d = str(data_niv1['updated'])+"|"+str(data_niv1['buy'])+"|"+str(data_niv1['sell'])+"|"+str(data_niv1['vol'])+"|"+str(data_2_niv1['updated'])+"|"+str(data_2_niv1['buy'])+"|"+str(data_2_niv1['sell'])+"|"+str(data_2_niv1['vol'])
        st = data_d
        #debug por terminal de respuesta enviada hacia ajax
        print("+"*20)
        print(str(st))
        #conversion a lista para envio a metodo de visualizacion en construccion
        stt = st.split("|")
        if len(data_p) <= 10:
            data_p.append(stt[0])
            data_s.append(stt[1])
            data_b.append(stt[2])
            print(str(data_p))
            if len(data_p) == 10:
                #hilo_grafica=threading.Thread(target=visualizacion,args=(data_p,data_s,data_b))
                #hilo_grafica.start()
                pass

                
        #Devolucion de String con peticiones hacia Ajax
        return st
    
   
#Clase que corre la aplicacion Flask en servidor local
class Aplicacion():
    #Creacion de ruta 127.0.0.1:5000/ Donde se hace la peticion a tidex
    @aplicacion.route("/",methods=['POST'])
    def main():
        return data.req()

    #Creacion de ruta 127.0.0.1:5000/vis En donde se crea la visualizacion de la aplicacion
    @aplicacion.route("/vis")
    def vis():
        return render_template('peticion.html',title="3355")
    #Creacion de ruta 127.0.0.1:5000/grafica en construccion para grafica
    @aplicacion.route("/grafica")
    def grafica():
        return render_template('graficado_simple.html')
    
    #creacion de Metodo de principal de aplicacion
    def inicio():
        aplicacion.run()





#Creacion de Main de Srcript
if __name__ == "__main__":
    #Apertura de Visualizacion de la aplicacion
    webbrowser.open_new('http://127.0.0.1:5000/vis')
    # llamado a clase de apliocacion y metodo principal de esta
    Aplicacion.inicio()
    
    


