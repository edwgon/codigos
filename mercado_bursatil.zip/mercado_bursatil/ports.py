import socket
for port in range(0,9000):
    s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result=s.connect_ex(("api.tidex.com/api/3/ticker/eth_btc",port))
    if result == 0:
        print(f'{port} Puerto abierto')
    else:
        print("Puerto no abierto")
s.close()