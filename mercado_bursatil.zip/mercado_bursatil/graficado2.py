from bokeh.plotting import figure, output_file,show
if __name__ == '__main__':
    output_file('graficado_simple.html')
    fig = figure()
    print(str(type(fig)))
    #print(str(help(figure)))
    valores = 5
    x_vals = list(range(valores))
    y_vals = list([2,1,4,7,8])
    z_vals = list([3,5,4,6,8])

    #help(fig)
    fig.line(x_vals,y_vals,line_width=2,line_color='blue')
    fig.line(x_vals,z_vals,line_width=2,line_color='red')
    show(fig)