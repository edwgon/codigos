from bs4 import BeautifulSoup
import pydocumentdb
import pydocumentdb.document_client as document_client
from crud_pro import *
#from runbootle2 import *
from lxml import html
import traceback
from multiprocessing import Process
from multiprocessing import Queue
import timestring
import os, sys
import threading
from parse import *
from req_tools import *
from utilities import *


'''
		configuraciones:
			self.pools = Cantidad de procesos paralelos
			self.localities = lista con Numero de iteraciones de localities a extraer;
			 para extraer todos con ['*']
			self.facilities = lista con Numero de iteraciones de faciolities a extraer;
			 para extraer todos con ['*']
			NOTAS: 
				-El numero de pools no debe ser mayor 
				 a la cantidad de elementos en la lista de localities
				-Si se extrae mas de una Locality; extraer todas las facilities
				 self.facilities = ['*']
'''
class extract():
	pools = 0
	regions = []
	localities = []
	facilities = []
	base_path = os.getcwd()
	dict_facilities = {}
	pars = parse()
	utt = gral()
	req = requests_tools()
	sep = "-___________________________________________________________________-"
	def iniciar(self,url):
		self.localities_pool = {}
		#print("Pool:\n"+str(self.localities_pool))
		self.url_region = url
		self.url_region2 = str(url).replace('/Food-CityList?OpenView&Count=999&','')
		self.r_query_1 = ''
		self.r_query_2 = ''
		self.r_query_3 = ''
		self.url_root = 'https://www.healthspace.com'
		self.pat_vio_tags = self.utt.pat_vio_tags
		self.pat_vio_code = self.utt.pat_vio_code
		url2 = url+'/Food-localityList?OpenView&Count=999&'
		self.url = url+'/Food-CityList?OpenView&Count=999&'
		self.dataset_metadata_id = 'oh_healthspace_food_service_facility_inspections'
		#print("111")
		if url != '':
			self.region = ''
			self.locality = ''
			self.url_locality =''
			self.item_license = {}
			self.localities_queue = 0
			self.facilities_queue = 0
			#print("222")
			#print("111"+str(url))
			self.general(url)
			#print("111")

	def __init__(self):
		#PROPERTY OBJECTS PROCESS CONTROL
		self.process_object = {'id':'','start_time':'','description':'','end_time':'','items_queue':{},\
		'last_updates':{},'messages':{},'error_messages':{},'subprocess_running':{},'services_used':{}}
		self.process_object.update({'description':'ohio_healthing_extraction','start_time':str(gral.all_utc()),\
		'services_used':{'cosmodb':'0','health_space':'0'}})
		self.process_object.update({'id':str(gral.hash_ids())})
		self.ANALIZER = argparse.ArgumentParser(description='Ohio oh_healthspace_food_service_facility_inspections')
		self.ANALIZER.add_argument(
		  "-u",
		  "--url",
		  help="Url Region",
		  default="None",
		  #action = "self.validate_action",
		  #type=int
		  required=False
		)
		self.ANALIZER.add_argument(
		  "-l",
		  "--loc",
		  help="Localities a Extraer",
		  default="None",
		  #action = "self.validate_action",
		  #type=int
		  required=False
		)
		self.ANALIZER.add_argument(
		  "-f",
		  "--fac",
		  help="Facilities a Extraer",
		  default="None",
		  #action = "self.validate_action",
		  #type=int
		  required=False
		)
		ARGUMENT = self.ANALIZER.parse_args()
		
		if ARGUMENT.loc: 
			if ARGUMENT.loc != '*':
				l_locs = []
				text_e = str(ARGUMENT.loc)
				l_locs = text_e.split(",")
				
				#print("Se envia filtro a localities: {l}\n\
				#	En {p} Pools".format(l=str(l_locs),p=str(self.pools)))
			else:
				l_locs = []
				l_locs.append('*')
				self.pools = 6
				#print("Se envian todas las localities: "+str(l_locs))
			self.localities = l_locs
			#print("Loc"+str(self.localities))
		if ARGUMENT.fac:
			if ARGUMENT.fac != '*':
				l_facs = []
				text_e = str(ARGUMENT.fac)
				l_facs = text_e.split(",")
				#print("Se envia filtro a facilities: "+str(l_facs))
				
			else:
				l_facs = []
				l_facs.append('*')
				#print("Se envian todas las facilities: "+str(l_facs))
			self.facilities = l_facs
			#print("Fac"+str(self.facilities))
		if ARGUMENT.url:
			#print("Se envia url: "+str(ARGUMENT.url))
			url = str(ARGUMENT.url)+'/Food-CityList?OpenView&Count=999&'
			self.iniciar(url)
	

	
	def send_object(self,obj):
		free_service = '0'
		while free_service == '0':
			time.sleep(1)
			free_service = self.process_object['services_used']['cosmodb']
		try:
			crud = cosmo_session()
			#print(str(crud))
			crud.update_document(iobject=obj,col='dataset_records_raw')
			#print("Objeto:\n\n"+str(obj)+"\n\n_______________")
		except:
			try:
				#print("1 er Corte")
				time.sleep(3)
				crud = cosmo_session()
				#print(str(crud))
				crud.update_document(iobject=obj,col='dataset_records_raw')
			except:
				try:
					#print("2 Corte")
					time.sleep(5)
					crud = cosmo_session()
					#print(str(crud))
					crud.update_document(iobject=obj,col='dataset_records_raw')
				except:
					try:
						#print("3 er Corte")
						time.sleep(10)
						crud = cosmo_session()
						#print(str(crud))
						crud.update_document(iobject=obj,col='dataset_records_raw')
					except:
						try:
							#print("4 er Corte")
							time.sleep(30)
							crud = cosmo_session()
							#print(str(crud))
							crud.update_document(iobject=obj,col='dataset_records_raw')
						except:
							pass
        finally:
            pass


	

	def req_localities(self,url_locality,locality_name,extract_region):
		r_locality = self.req.general_request(url_locality)
		if r_locality != None:
			page_locality = r_locality
			if page_locality != None:
				p_l = page_locality
				e_r = extract_region
				l_n = locality_name
				f = self.facilities
				u = self.url_root
				dmi = self.dataset_metadata_id
				l_urls_facilities = \
				self.pars.parse_localities(page=p_l,reg=e_r,loc=l_n,facs=f,dmi=dmi,url=u)
				len_l_urls_facilities = int(len(l_urls_facilities))
				if len_l_urls_facilities > 0:
					for it_l_urls_facilities in l_urls_facilities:
						url_facility = it_l_urls_facilities['facility_url']
						object_facility = it_l_urls_facilities
						#print("URL"+str(it_l_urls_facilities['facility_url']))
						r_facility = self.req.general_request(url_facility)
						if r_facility != None:
							page_facility = r_facility
							if page_facility != None:
								p_f = page_facility
								o_f = object_facility
								u2 = self.url_region2
								dmi = self.dataset_metadata_id
								l_urls_inspections = self.pars.parse_inspections(page=p_f,obj=o_f,dmi=dmi,url=u2)
								if l_urls_inspections != None:
									len_l_urls_inspections = int(len(l_urls_inspections))
									if len_l_urls_inspections != None:
										if len_l_urls_inspections > 0:
											object_inspections = {}
											object_facility.update({'inspections':l_urls_inspections})
											for it_l_urls_inspections in l_urls_inspections:
												url_inspection = it_l_urls_inspections['inspection_url']
												object_inspections = it_l_urls_inspections
												#print("URL"+str(it_l_urls_inspections['inspection_url']))
												r_violations = self.req.general_request(url_inspection)
												if r_violations != None:
													page_violation = r_violations
													object_ins = {}
													page = page_violation
													obj = object_inspections
													dmi = self.dataset_metadata_id
													l_urls_violations = self.pars.parse_violations(pag=page,obj=obj,dmi=dmi)
													#print("444444"+str(l_urls_violations))
													object_facility.update({'violations':l_urls_violations})
											self.send_object(object_facility)






	def general(self,url):
		#print("333")
		r_dict_region = self.req.region_request(url)
		if r_dict_region != None:
			#print(r_dict_region)
			extract_region = r_dict_region['region']
			extract_region = str(extract_region)
			page_region = r_dict_region['r']
			if page_region != None:
				locs = self.localities
				u_l = self.url_locality
				u_r = self.url_root
				l_urls_localities = self.pars.parse_region(page=page_region,locs=locs,u_l=u_l,u_r=u_r)
				if l_urls_localities != None:
					i_l_locs = int(len(l_urls_localities))
					if i_l_locs == 1:
						self.pools = 1
					elif i_l_locs > 1 and i_l_locs < 6:
						self.pools = int(i_l_locs)
					elif i_l_locs > 6:
						self.pools = 6
					self.localities_pool = {}
					for it in range(0,int(self.pools)):
						self.localities_pool.update({str(it):{'th':'','state':'0','loc':'','reg':''}})
					queue_urls_localities = int(len(l_urls_localities))
					items_urls_localities = 0
					while items_urls_localities < queue_urls_localities:
						for k,v in self.localities_pool.items():
							#print(str(v['state']))
							if v['state'] == '0':
								full_pool = True
								while full_pool:
									v['loc'] = str(l_urls_localities[items_urls_localities])
									v['reg'] = str(extract_region)
									v['state'] = '1'
									v['item'] = items_urls_localities
									full_pool = False
							if v['state'] == '1':
								url_locality = l_urls_localities[int(items_urls_localities)]['url']
								l_locality = l_urls_localities[int(items_urls_localities)]['locality']
								thread = threading.Thread(target=self.req_localities,args=(url_locality,l_locality,extract_region))
								#req_localities(self,url_locality,locality_name,extract_region)
								self.l_pools.append(thread)
								items_urls_localities += 1
								thread.start()
								print(self.sep+"Inicio Hilo para"+str(v['reg'])+"Pool"+str(self.l_pools)+self.sep)
								v['state'] = '2'
								v['th'] = thread
							if v['state'] == '2':
								th = v['th']
								v_th = th.isAlive()
								if v_th == False:
									tx_mensage = self.sep+"Acaba Hilo para\nRegion -> "+str(v['reg'])+"\n\
										Locality -> "+str(v['loc'])+"\nPool"+str(self.l_pools)+self.sep+\
										"\nprocessed Items Localities-> \n\t"+str(items_urls_localities)+\
										"\nQueue Items Localities-> \n\t"+str(queue_urls_localities)+\
										"\nRegion-> \n\t"+str(extract_region)
									print(str(tx_mensage))
									v['state'] = '0'
									sys.stderr.write(str(tx_mensage))
if __name__ == '__main__':
	extract()



