from bs4 import BeautifulSoup
import re
import datetime
import hashlib
from utilities import *
from lxml import html


class parse():
	ut = gral()
	def parse_region(self,page='',locs='',u_l='',u_r=''):
		localities = locs
		url_locality = u_l
		url_root = u_r
		response_tree = html.fromstring(page.content)
		soup = BeautifulSoup(page.content, 'lxml')
		#print(soup.prettify())
		links_localities = response_tree.xpath('//a[contains(@href,"Food-List-ByName")]')
		#"links =  
		localities_queue = int(len(links_localities))
		#print("Localities: "+str(len(links_localities)))
		#print("Type: "+str(type(links_localities[0])))
		if localities_queue != 0: 
			l_urls = []
			#print("222"+str(self.localities))
			if len(localities) > 0:
				v_locality = localities[0]
				if v_locality == '*':
					localities = links_localities
					for link in links_localities:
						dict_locality = {}
						#print("ELE 1"+str(link))
						link = html.tostring(link)
						#print("Link2: "+str(link)+"Type\n"+str(type(link)))
						soup2 = BeautifulSoup(str(link))
						locality = soup2.find('a').contents[0]
						link_text = soup2.find('a')['href']
						link_text2 = soup2.find('a')['href']
						#print("Loc: "+str(self.locality))
						#print("Link"+str(link_text))
						link_text = link_text.replace("&Count=50&", "&Count=5000&")
						url_locality = str(url_root)+str(link_text)
						#print("8888888888888888888888888888888888888888888"+str(self.url_locality))
						dict_locality .update({'url':url_locality,'locality':locality,'queue':localities_queue})
						l_urls.append(dict_locality)
					#print("Lista Elementos\n\t"+str(l_urls))
					return l_urls

				else:
					l_it_items = []
					l_it_items = list(localities)
					#print("Lista de Localities"+str(l_it_items))
					localities = []
					for it_locality in l_it_items:
						it_locality = int(it_locality)
						locali = links_localities[it_locality]
						localities.append(locali)
					if len(localities) > 0:
						for it_locality in localities:
							#print("ELE 1"+str(it_locality))
							dict_locality = {}
							link = html.tostring(it_locality)
							#print("Link2: "+str(link)+"Type\n"+str(type(link)))
							soup2 = BeautifulSoup(str(link))
							locality = soup2.find('a').contents[0]
							link_text = soup2.find('a')['href']
							link_text2 = soup2.find('a')['href']
							#print("Loc: "+str(self.locality))
							#print("Link"+str(link))
							link_text = link_text.replace("&Count=50&", "&Count=5000&")
							url_locality = str(url_root)+str(link_text)
							#print("8888888888888888888888888888888888888888888"+str(self.url_locality))
							dict_locality .update({'url':url_locality,'locality':locality,'queue':localities_queue})
							l_urls.append(dict_locality)
						#print("Lista Elementos\n\t"+str(l_urls))
						return l_urls
					
			
		else:
			return None
	def parse_localities(self,page='',reg='',loc='',facs='',dmi='',url=''):
		dataset_metadata_id = dmi
		page_locality = page
		region_n = reg
		locality_n = loc
		url_root = url
		dict_facilities = {}
		bsObj = BeautifulSoup(page_locality.content, 'lxml')
		links_fac = bsObj.findAll('table')[1].find_all('a', href=True)
		#print('RESPONSE URL : %s' % str(page_locality.url))
		facilities_queue = int(len(links_fac))
		#print('Number of results of Facilities %s' % str(len(links_fac)))
		if facilities_queue != 0:
			l_urls = []
			v_facility = facs[0]
			if v_facility != '*':
				for it_facility in facs:
					facility = int(it_facility) 
					i = facility
					link = links_fac[facility]
					dict_facilities = {}
					rows = bsObj.findAll('table')[1].tbody.findAll('tr')[i]
					cells = rows.find_all('td')
					facility_id = link['href'].split('=')[1]
					facility_name = cells[0].get_text()
					facility_location = cells[1].get_text()
					#print(str(facility_id))
					#print(str(facility_name))
					#print(str(facility_location))
					link_facility = str(url_root)+str(link['href'])
					last_inspection = cells[2].get_text()
					last_inspection = str(last_inspection)
					date_last_inspection = str(last_inspection)
					date_now = self.ut.all_utc()
					date_now = str(date_now)
					string_key = str(dataset_metadata_id) + str(facility_id)
					obj_hash = hashlib.sha224(string_key.lower().encode())
					vali_id = obj_hash.hexdigest()
					id_fac = obj_hash.hexdigest()
					dict_facilities.update({'id':id_fac,'dataset_metadata_id':str(dataset_metadata_id),\
							'facility_name':str(facility_name),'facility_location':str(facility_location),\
							'facility_region':str(region_n),'facility_locality':str(locality_n),\
							'facility_id':str(facility_id),'facility_type':None,\
							'facility_last_inspection':date_last_inspection,\
							'facility_url':str(link_facility),'created_at':str(date_now),'updated_at':'Never','inspections':[]})
					l_urls.append(dict_facilities)
					#Unindent
				return l_urls
				
			else:
				for i, link in enumerate(links_fac):
					rows = bsObj.findAll('table')[1].tbody.findAll('tr')[i]
					cells = rows.find_all('td')
					facility_id = link['href'].split('=')[1]
					facility_name = cells[0].get_text()
					facility_location = cells[1].get_text()
					#print(str(facility_id))
					#print(str(facility_name))
					#print(str(facility_location))
					link_facility = str(url_root)+str(link['href'])
					last_inspection = cells[2].get_text()
					last_inspection = str(last_inspection)
					date_last_inspection = str(last_inspection)
					date_now = self.ut.all_utc()
					date_now = str(date_now)
					string_key = str(dataset_metadata_id) + str(facility_id)
					obj_hash = hashlib.sha224(string_key.lower().encode())
					vali_id = obj_hash.hexdigest()
					id_fac = obj_hash.hexdigest()
					dict_facilities.update({'id':id_fac,'dataset_metadata_id':str(dataset_metadata_id),\
							'facility_name':str(facility_name),'facility_location':str(facility_location),\
							'facility_region':str(region_n),'facility_locality':str(locality_n),\
							'facility_id':str(facility_id),'facility_type':None,\
							'facility_last_inspection':date_last_inspection,\
							'facility_url':str(link_facility),'created_at':str(date_now),'updated_at':'','inspections':[]})
					l_urls.append(dict_facilities)
				#Unindent
				return l_urls
				
		else:
			return None

	def parse_inspections(self,page='',obj='',dmi='',url=''):
		object_inspections = obj
		page_inspections = page
		url_region2 = url
		dataset_metadata_id = dmi
		bsObj = BeautifulSoup(page_inspections.text, 'lxml')
		link_google = bsObj.findAll('table')[2].findAll('td')[0].find_all('a', href=True)
		info_list = bsObj.findAll('table')[1].findAll('tr')
		#print("INFO"+str(info_list))
		for num, row in enumerate(info_list):
			if num == 1:
				facility_type = row.findAll('td')[1].get_text()
				#print (facility_type)
			if num == 2:
				risk_rating = row.findAll('td')[1].get_text()
				#print (risk_rating)
			if num == 3:
				facility_phone_number = row.findAll('td')[1].get_text()
		if link_google:
			link_google = str(link_google[0]['href'])
			#print("Google Maps"+)
			object_inspections.update({'google_maps_url':str(link_google),'facility_type':str(facility_type),\
				'facility_phone_number':str(facility_phone_number),'facility_risk_rating':str(risk_rating)})
		else:
			object_inspections.update({'facility_type':str(facility_type),\
				'facility_phone_number':str(facility_phone_number),'facility_risk_rating':str(risk_rating)})
		links_inspections = bsObj.findAll('table')[4].find_all('a', href=True)
		l_r_inspections = []
		l_inspections = []
		if links_inspections:
			inspection = {}
			for i, link in enumerate(links_inspections):
				id_ins = str(link['href'].split("=")[1])
				#print("inspection Id" +str(link['href'].split("=")[1]))
				rows = bsObj.findAll('table')[4].findAll('tr')[i]
				cells = rows.find_all('td')
				text_inspections = str(cells[2].get_text().strip())
				valid_inspection = self.ut.rege(self.ut.patron_valid_inspections,text_inspections)
				nvalid_inspection = valid_inspection['r']
				cvalid_inspection = valid_inspection['c']
				if nvalid_inspection > 0:
					i_id = self.ut.hash_ids([dataset_metadata_id,object_inspections['facility_region'],object_inspections['facility_location'],id_ins])
					inspection.update({'inspection_id':str(id_ins),})
					dict_r_inspections = {}
					type_i = str(cells[0].get_text().strip())
					date_i = str(cells[1].get_text().strip())
					summary = str(cells[2].get_text().strip())
					url_i = str(url_region2)+"/"+str(link['href'])
					#print("inspection type" +str(cells[0].get_text().strip()))
					#print("inspection date" +str(cells[1].get_text().strip()))
					#print("inspection summary"+str(cells[2].get_text().strip()))
					#print("inspection url" +str(link['href']))
					dict_r_inspections.update({'inspection_type':str(type_i),'inspection_date':str(date_i),\
				'inspection_summary':str(summary),'inspection_url':str(url_i)})
					inspection.update({'inspection_type':str(type_i),'inspection_date':str(date_i),\
				'inspection_summary':str(summary),'inspection_url':str(url_i)})
					l_r_inspections.append(dict_r_inspections)
					l_inspections.append(inspection)
					inspection = {}
				#Unindent
				dict_response = {}
				dict_response.update({'r_dict':list(l_r_inspections),'obj_dict':list(l_inspections)})
				object_inspections['inspections'] = list(l_inspections)
				#print("Inspection List"+str(l_r_inspections))
			return l_r_inspections
		else:
			return None


	def parse_violations(self,pag='',obj='',dmi=''):
		page_violations = pag
		object_violations = obj
		dataset_metadata_id = dmi
		bsObj = BeautifulSoup(page_violations.text, 'lxml')
		l_item3 = []
		if bsObj.findAll("table")[-1].find('thead').find('th'):
			thead = bsObj.findAll("table")[-1].find('thead').find('th').get_text()
		else:
			thead = None

		if thead == 'Comments':
			tcomment = bsObj.findAll("table")[-1].findAll('td')
			comment = ''
			for i in tcomment:
				comment = comment + (i.get_text() + '\n')
		else:
			comment = None
		
		comment = comment	  

		items_violations = []
		ids_violations = []

		if bsObj.find("div", {"id": "general"}):
			div = bsObj.find("div", {"id": "general"})
			p_vio = div.find("p")
			cont_vio = 0
			item3 = {}
			vio_id = ''
			text_an = ""
			text_an2 = ""
			text = ''
			for it_p in p_vio:
				cont_vio += 1
				coin_desc = self.ut.pat_vio.findall(str(it_p))
				le_vios = int(len(coin_desc))
				#print(str(cont_vio))
				if le_vios > 0:
					if cont_vio == 1 or cont_vio == 2:
						description = str(coin_desc[0])
						#print("44444"+str(str(it_p)))
						item3 = {'violation_code':'','violation_description':'','violation_is_critical':False,'violation_observation':'','violation_is_repeat':False,'violation_corrected_during_inspection':False,'violation_corrective_action':''}
						coin_code = self.ut.pat_vio_code.findall(str(it_p))
						le_vios_code = int(len(coin_code))
						if le_vios_code > 0:
							item3.update({'violation_code':str(coin_code[0])})
							viocode = str(coin_code[0])+" / "
							desc_vio = str(description).replace(str(viocode),'')
							item3.update({'violation_description':str(desc_vio)})
							#print("OBJH."+str(item3))
						#print("Nuevo OBJ: \n"+str(item3))
				text_p = str(it_p).strip()
				if text_p != '' and text_p != '<br/>':
					#print("__________\n["+str(text_p)+"]")
					text_an2 = text_an
					text_an = str(text_p)
				
				for_obs = False
				#print("text:\n{t}\n\nText_AN:{at}\n".format(t=str(text),at=str(text_an)))
				#print("NextOOOOO\n"+str(it_p)+"\n\n")
				try:		 
					text = str(it_p.get_text()).strip()
					text = str(text).strip()
					#print("text:\n{t}\n\nText_AN:{at}\nText An 2:{a2}".format(t=str(text),at=str(text_an),a2=str(text_an2)))
				except:
					pass
					#if text != '' and text != '<br/>':
				#text_an2 = text_an
				#text = str(it_p.get_text()).strip()
				#print("text:\n{t}\n\nText_AN:{at}\nText An 2:{a2}".format(t=str(text),at=str(text_an),a2=str(text_an2)))
				
				if text == "Critical":
					item3.update({'violation_is_critical':True})
					#print("OBJH."+str(item3))
					#text_an = text
				if text == "Corrected During Inspection":
					item3.update({'violation_corrected_during_inspection':True})
					#print("OBJH."+str(item3))
					#text_an = text
				if text == "Critical Repeat":
					item3.update({'violation_is_critical':True})
					item3.update({'violation_is_repeat':True})
					#print("OBJH."+str(item3))
					#text_an = text
				if str(it_p).find('<font color="Green">') >= 0:
					it_font = str(it_p)#<font color="Green"><i>
					it_font = str(it_font).replace('<font color="Green"><i>','')
					it_font = str(it_font).replace('</i></font>','')
					#print("FONT"+str(it_font))
					item3.update({'violation_corrective_action':str(it_font).strip()})
					item3.update({'violation_observation':str(text_an2)})
					#print("OBJH."+str(item3))
					#print("OBS\n"+str(p_vio[cont_vio-2]))
					#print("OBSSS:\n"+str(text_an2))
					l_item3.append(item3)
					items_violations.append(item3)
					cont_vio = 0
				#print("__________\n"+str(text))
		if  bsObj.find("div", {"id": "manager"}):
			div = bsObj.find("div", {"id": "manager"})
			p_vio = div.find("p")
			cont_vio = 0
			item3 = {}
			text_an = ""
			text_an2 = ""
			text = ''
			for it_p in p_vio:
				cont_vio += 1
				coin_desc = self.ut.pat_vio.findall(str(it_p))
				le_vios = int(len(coin_desc))
				#print(str(cont_vio))
				if le_vios > 0:
					if cont_vio == 1 or cont_vio == 2:
						description = str(coin_desc[0])
						#print("44444"+str(str(it_p)))
						item3 = {'violation_code':'','violation_description':'','violation_is_critical':False,'violation_observation':'','violation_is_repeat':False,'violation_corrected_during_inspection':False,'violation_corrective_action':''}
						coin_code = self.ut.pat_vio_code.findall(str(it_p))
						le_vios_code = int(len(coin_code))
						if le_vios_code > 0:
							item3.update({'violation_code':str(coin_code[0])})
							viocode = str(coin_code[0])+" / "
							desc_vio = str(description).replace(str(viocode),'')
							item3.update({'violation_description':str(desc_vio)})
							#print("OBJH."+str(item3))
						#print("Nuevo OBJ: \n"+str(item3))
				text_p = str(it_p).strip()
				if text_p != '' and text_p != '<br/>':
					#print("__________\n["+str(text_p)+"]")
					text_an2 = text_an
					text_an = str(text_p)
				
				for_obs = False
				#print("text:\n{t}\n\nText_AN:{at}\n".format(t=str(text),at=str(text_an)))
				try:
					#print("NextOOOOO\n"+str(it_p)+"\n\n")		   
					text = str(it_p.get_text()).strip()
					text = str(text).strip()
					#print("text:\n{t}\n\nText_AN:{at}\nText An 2:{a2}".format(t=str(text),at=str(text_an),a2=str(text_an2)))
					#if text != '' and text != '<br/>':
					#text_an2 = text_an
					#text = str(it_p.get_text()).strip()
					#print("text:\n{t}\n\nText_AN:{at}\nText An 2:{a2}".format(t=str(text),at=str(text_an),a2=str(text_an2)))
					
					if text == "Critical":
						item3.update({'violation_is_critical':True})
						#print("OBJH."+str(item3))
						#text_an = text
					if text == "Corrected During Inspection":
						item3.update({'violation_corrected_during_inspection':True})
						#print("OBJH."+str(item3))
						#text_an = text
					if text == "Repeat":
						item3.update({'violation_is_repeat':True})
						#print("OBJH."+str(item3))
						#text_an = text
					if str(it_p).find('<font color="Green">') >= 0:
						it_font = str(it_p)#<font color="Green"><i>
						it_font = str(it_font).replace('<font color="Green"><i>','')
						it_font = str(it_font).replace('</i></font>','')
						#print("FONT"+str(it_font))
						item3.update({'violation_corrective_action':str(it_font).strip()})
						item3.update({'violation_observation':str(text_an2)})
						#print("OBJH."+str(item3))
						#print("OBS\n"+str(p_vio[cont_vio-2]))
						#print("OBSSS:\n"+str(text_an2))
						l_item3.append(item3)
						items_violations.append(item3)
						cont_vio = 0
				except Exception as exgr:
					text= ''
					#print("Error Create Json:\n\t{a}\n\nType:\n\t{b}\n\nArgs:\n\t{c}\n\n\nSys:\n\t{d}".format(a=str(exgr),b=str(type(exgr)),d=str(sys.exc_info()[0]),c=str(exgr.args)))
				#print("__________\n"+str(text))
		if not (bsObj.find("div", {"id": "general"}) or bsObj.find("div", {"id": "manager"})):
			#print("\n\n\n3 Funcion")
			item3 = {}
			div = bsObj.find('body')
			try:
				tab = div.findAll("div",{'id':r'view:_id1:uiContainer'})[3]
			except:
				tab = None
			if tab != None:
				#print("TBODY\n\n[[[\n\n"+str(div)+"\n\n]]]]\n\n")
				#print("TABLE\n\n[[[\n\n"+str(tab)+"\n\n]]]]\n\n")
				p_vio = tab.findAll("table",{'class':'table table-bordered table table-striped table table-condensed'})
				#print("PVIO"+str(p_vio[0]))
				pp_vio = p_vio[0].findAll("tr")
				cont_vio = 0
				l_item3 = []
				text_an = ""
				text_an2 = ""
				text = ''
				item3 = {}
				for it_p in pp_vio:
					#print("__________________________")
					element = it_p.find("td")
					#print("ITEM__VIO\n\t"+str(element))
					cont_vio += 1
					#print("CONT VIO:\n\t"+str(cont_vio))
					cont_fields =0
					vio_id = ''
					vio_code = ''
					print("ELEMENT "+str(element))
					time.sleep(4)
					if element != None and element != 'None' and element != 'NONE': 
						for it_ele in element.contents:
							it_ele_t = it_ele
							it_ele = str(it_ele).strip()
							if it_ele != '<br/>' and it_ele != '':
								cont_fields += 1
								if cont_fields == 1:
									coin_desc = self.ut.pat_vio.findall(str(it_ele))
									it_ele = str(it_ele).strip()
									le_vios = int(len(coin_desc))
									#print(str(cont_vio))
									if le_vios > 0:
										item3 = {'violation_code':'','violation_description':'','violation_is_critical':False,'violation_observation':'','violation_is_repeat':False,'violation_corrected_during_inspection':False,'violation_corrective_action':''}
										vio_code = str(coin_desc[0])
										if vio_code == it_ele:
											#print("REGEX\n"+str(coin_desc[0]))
											#print("_____________")
											item3.update({'violation_code':str(vio_code)}) 
											#print("ITEM__FIELD_CODE\n"+str(it_ele)+"\n\nCont:\n"+str(cont_fields))
								if cont_fields > 1 and vio_code != '':
									if cont_fields == 2:
										field_t = str(it_ele)
										field = str(it_ele)
										field = self.ut.pat_vio_tags.sub('',it_ele)
										le_vios2 = self.ut.rege(self.ut.pat_vio2,field_t)
										nle_vios2 = le_vios2['r']
										cle_vios2 = le_vios2['c']
										if nle_vios2 > 0:
											element = str(cle_vios2)
											#print("MATCH REGEX 2"+str(cle_vios2))
											element = str(it_ele).strip().lower()
											if element.find("critical") != -1:
												item3.update({'violation_is_critical':True})
												#print("IS CRITICAL: "+str(element))
											if element.find("repeat") != -1:
												item3.update({'violation_is_repeat':True})
												#print("IS REPEAT: "+str(element))
											#print("ITEM__FIELD_CRITICAL\n"+str(field))
											#print("ITEM__FIELD_CRITICAL\n"+str(field))
										else:
											l_obs = self.ut.rege(self.ut.pat_obs,field)
											nl_obs = le_vios2['r']
											cl_obs = le_vios2['c']
											if nl_obs > 0:
												if element.find("(CORRECTED DURING INSPECTION)") != -1:
													field = str(element).replace("(CORRECTED DURING INSPECTION)",'').capitalize()
													item3.update({'violation_corrected_during_inspection':True})
													#print("IS CORRECTED IN INSPECTION: "+field_t)
												#print("ITEM__FIELD_OBSERVED\n"+str(field))
												vio_id = self.ut.self.ut.hash_ids([dataset_metadata_id,vio_code,field_t])
												#print("Vio_IDDD"+str(vio_id))
												item3.update({'violation_id':vio_id,'violation_observation':field_t})
									if cont_fields == 3:
										field = str(it_ele)
										it_ele_t = str(it_ele)
										#print("ITEM__FIELD_OBSERVED\n"+str(field))
										element = str(it_ele).strip().upper()
										le_vios3 = self.ut.rege(self.ut.pat_vio2,field)
										nle_vios3 = le_vios3['r']
										cle_vios3 = le_vios3['c']
										#if field_t.find("<font color=\"RED\">") != -1:
										if nle_vios3 != 0:
										#if field_t.find("<font color=\"RED\">") != -1:
											#print("MATCH REGEX 3"+str(it_ele))
											element = str(it_ele).strip().lower()
											if element.find("critical") != -1:
												item3.update({'violation_is_critical':True})
												#print("IS CRITICAL: "+str(element))
											if element.find("repeat") != -1:
												item3.update({'violation_is_repeat':True})
												#print("IS REPEAT: "+str(element))
											#print("ITEM__FIELD_CRITICAL\n"+str(field))
											#print("ITEM__FIELD_CRITICAL\n"+str(field))
										else:
											
											l_obs = self.ut.rege(self.ut.pat_obs,field)
											nlobs = l_obs['r']
											clobs = l_obs['c']
											if nlobs > 0:
												if element.find("(CORRECTED DURING INSPECTION)") != -1:
													field = str(element).replace("(CORRECTED DURING INSPECTION)",'').capitalize()
													item3({'violation_corrected_during_inspection':True})
													#print("IS CORRECTED IN INSPECTION: "+it_ele_t)
												#print("ITEM__FIELD_OBSERVED\n"+str(field))
												vio_id = self.ut.hash_ids([dataset_metadata_id,vio_code,field_t])
												#print("VIO Id"+str(vio_id))
												item3.update({'violation_id':vio_id,'violation_observation':it_ele_t})
										
										
									if cont_fields == 4:
										#<font color="GREEN">
										field = str(it_ele)
										field_t = str(it_ele)
										field = self.ut.pat_vio_tags.sub('',it_ele)
										le_vios4 = self.ut.rege(self.ut.pat_vio3,field_t)
										nle_vios4 = le_vios4['r']
										cle_vios4 = le_vios4['c']
										if nle_vios4 > 0:
											#print("MATCH REGEX"+str(it_ele))
											item3.update({'violation_corrective_action':str(field).strip()})
										#field_t = field_t.find("i")
											#print("ITEM__FIELD_ACTION\n"+str(field))
											#print("ELEMENT:\n\n\n"+str(item3)+"\n\n")
											try:
												id_vio = item3['violation_id']
											except:
												id_vio=None
											if id_vio != None:
												valid_id_vio = id_vio in ids_violations
												if valid_id_vio == False:
													l_item3.append(item3)
													item3 = {}
									if cont_fields == 5:
										field = str(it_ele)
										field_t = str(it_ele)
										field = self.ut.pat_vio_tags.sub('',it_ele)
										le_vios5 = self.ut.rege(self.ut.pat_vio3,field_t)
										nle_vios5 = le_vios5['r']
										cle_vios5 = le_vios5['c']
										if nle_vios5 > 0:
											#print("MATCH REGEX"+str(it_ele))
											item3.update({'violation_corrective_action':str(field).strip()})
										#field_t = field_t.find("i")
											#print("ITEM__FIELD_ACTION\n"+str(field))
											#print("ELEMENT:\n\n\n"+str(item3)+"\n\n")
											#valid_id_violations = "violation_id" in item3
											#print("Valid"+str(valid_id_violations))
											#if item3['violation_id']:
											try:
												id_vio = item3['violation_id']
											except:
												id_vio=None
											if id_vio != None:
												valid_id_vio = id_vio in ids_violations
												if valid_id_vio == False:
													l_item3.append(item3)
													item3 = {}
								#print("ITEM__FIELD\n"+str(it_ele)+"\n\nCont:\n"+str(cont_fields))
					#print("__________________________")
					#print("\n\n\n\n\tINGRESO TERCERA FUNCION\n\n\n\n")
					print("Objeto violations "+str(l_item3))
					object_violations.update({'violations':l_item3})
					return object_violations	