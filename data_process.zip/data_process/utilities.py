import re
import datetime
import hashlib
import csv
import requests
import time
import sys

class gral():
	patron_valid_inspections = re.compile(r'[0-9]{1,4}\scritical\s&\s[0-9]{1,4}\snon-critical')
	pat_vio = re.compile(r'([0-9]{4}-[0-9]-[0-9]{2}[.][0-9][\\(0-9A-Za-z\\)]+[^\n]+|[0-9]{4}-[0-9]-[0-9]{2}[.][0-9][^\n]+)')
	pat_vio_code = re.compile(r'([0-9]{4}-[0-9]-[0-9]{2}[.][0-9][\\(0-9A-Za-z\\)]+|[0-9]{4}-[0-9]-[0-9]{2}[.][0-9])')
	pat_vio_tags = re.compile(r'<[^>]+>')
	pat_vio2 = re.compile(r'(<font\scolor=.RED.>)')
	pat_obs = re.compile(r'(^[^<?+>]*)*')
	pat_vio3 = re.compile(r'(<font\scolor=.GREEN.>)')

	def text_date_v(fecha_str):
		tx_date = timestring.Date('monday, aug 15th 2015 at 8:40 pm').date
	def text_date(fecha_str):
		result_date = datetime.strptime(fecha_str,'%d-%b-%Y')
		#print("An"+str(fecha_str)+"\nDes"+str(result_date))
		return result_date
	def h_utc():
		utc_date = datetime.datetime.utcnow()
		result_date = utc_date.strftime("%H:%M:%S")
		return result_date
	def d_utc(self):
		utc_date = datetime.datetime.utcnow()
		result_date = utc_date.strftime("%Y-%m-%d")
		return result_date
	def all_utc(self):
		utc_date = datetime.datetime.utcnow()
		result_date = str(utc_date.strftime("%Y-%m-%d_%H:%M:%S"))
		return result_date
	def clean_text(self,text):
		tx = str(text)
		tx = str(tx).strip()
		tx = str(tx).replace('\n','')
		tx = str(tx).replace('\s','')
		tx = str(tx).replace('\t','')
		tx = self.pat_vio_tags.sub('',tx)
		#tx = str(str(tx).strip)
		return tx



	def rege(self,patron,text):
		coin_desc = patron.findall(str(text))
		it_ele = str(text).strip()
		le_vios = int(len(coin_desc))
		l_res = {'r':'','c':''}
		l_res.update({'r':int(le_vios)})
		#print("Valid RegEx:\n"+str(le_vios)+"\n\nPara:\n"+str(text))
		if le_vios == 0:
			coin_desc.append('None')
		else:
			l_res.update({'c':str(text)})
		#print(str(l_res))
		return l_res
	def hash_ids(self,l_fields):
		string_id = ''
		for items in l_fields:
			items = str(items)
			items = self.clean_text(items)
			if string_id != '':
				string_id += str(items)
			else:
				string_id += str(items)
		
		obj_hash = hashlib.sha224(string_id.encode())
		vio_id = obj_hash.hexdigest()
		#print("Hash Id"+str(vio_id))
		#string_id2 = string_id.hexdigest()
		#ob_dec = obj_hash.decode(sha224)
		#print("String para Id"+str(ob_dec))
		if vio_id != '':
			return vio_id
		else:
			return None


class requests_tools():
	def region_request(self,url):
		seconds = 5
		v_request = False
		while v_request == False:
			url_lower = url.lower()
			region = url_lower.split('ohio')[1].split('/')[1]
			#print("Region "+str(region))
			time.sleep(seconds)
			s = requests.Session()
			r = s.get(url)
			r_dict = {}
			if r.status_code == 200:
				v_request = True
			else:
				seconds += 5
			#print("espera gral")
			if seconds > 60:
				sys.stderr.write("! Error {}  url {}\n".format(r.status_code, url))
				return None

		else:
			r_dict.update({'r':r,'region':region})
			return r_dict


	def general_request(self,url):
		seconds = 5
		v_request = False
		while v_request == False:
			time.sleep(seconds)
			s = requests.Session()
			r = s.get(url)
			v_request = False
			if r.status_code == 200:
				v_request = True
			else:
				seconds += 5
			#print("espera gral")
			if seconds > 60:
				sys.stderr.write("! Error {}  url {}\n".format(r.status_code, url))
				return None
		return r