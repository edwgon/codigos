import predefine_config as cc
import argparse
import pydocumentdb
import pydocumentdb.document_client as document_client
import os, sys
import pymongo
from pymongo import MongoClient


class mongo_session():
	def __init__(self,connection="2"):
		dict_con = cc.it_con(connection)
		self.SERVER = dict_con['SERVER']
		self.PORT = dict_con['PORT']
		self.CONNECTION = dict_con['CONNECTION']
		self.DEFAULT_DB = dict_con['DEFAULT_DB']
		self.DEFAULT_COLL = dict_con['DEFAULT_COLL']
		self.CLIENT = MongoClient(self.SERVER,self.PORT)
		self.DB = mongoClient.risk
		self.COLLECTION = self.DB.extract
		print("{s}Connection=\n\t{c}{ss}Server=\n\t{e}{ss}Data Base=\n\t{db}{ss}"\
			.format(s=self.SEP,c=self.CONNECTION,ss=self.SEP2,e=self.SERVER,db=self.DEFAULT_DB))
	def read_documents(self,):
		pass
		    	 


class cosmo_session():
	def __init__(self,connection="1"):
		dict_con = cc.it_con(connection)
		self.ENDPOINT = dict_con['ENDPOINT']
		self.MASTERKEY = dict_con['MASTERKEY']
		self.CONNECTION = dict_con['CONNECTION']
		self.DEFAULT_DB = dict_con['DEFAULT_DB']
		self.DEFAULT_COLL = dict_con['DEFAULT_COLL']
		self.CLIENT = document_client.DocumentClient(self.ENDPOINT, {'masterKey': self.MASTERKEY})
		self.DATABASE = 'dbs/'+str(self.DEFAULT_DB)
		self.COLLECTION = self.DATABASE + '/colls/' + self.DEFAULT_COLL
		self.SEP = "_________________________________________________________________________________________________"
		self.SEP2 = "_______________________________________________________"
		print("{s}Connection=\n\t{c}{ss}Endpoint=\n\t{e}{ss}Data Base=\n\t{db}{ss}"\
			.format(s=self.SEP,c=self.CONNECTION,ss=self.SEP2,e=self.ENDPOINT,db=self.DEFAULT_DB))
	

	def get_config(self):
		dict_conn = {}
		dict_conn['ENDPOINT'] = self.ENDPOINT
		dict_conn['MASTERKEY'] = self.MASTERKEY
		dict_conn['CONNECTION'] = self.CONNECTION
		dict_conn['DEFAULT_DB'] = self.DEFAULT_DB
		dict_conn['DEFAULT_COLL'] = self.DEFAULT_COLL
		dict_conn['CLIENT'] = self.CLIENT
		print("{s}Connection=\n\t{c}\n{ss}\nEndpoint=\n\t{e}\n{ss}\nData Base=\n\t{db}\n{ss}\nClient=\n\t{cl}\n{ss}\n{s}\n"\
			.format(s=self.SEP,c=self.CONNECTION,ss=self.SEP2,e=self.ENDPOINT,db=self.DEFAULT_DB,cl=str(self.CLIENT)))
		return dict_conn
	def get_ENDPOINT(self):
		return self.ENDPOINT
	def set_ENDPOINT(self,ENDPOINT):
		self.ENDPOINT = ENDPOINT
		return str("Se cambio dato por:\n{d}".format(d=str(self.ENDPOINT)))

	def get_MASTERKEY(self):
		return self.MASTERKEY
	def set_MASTERKEY(self,MASTERKEY):
		self.MASTERKEY = MASTERKEY
		return str("Se cambio dato por:\n{d}".format(d=str(self.MASTERKEY)))

	def get_DEFAULT_COLL(self):
		return self.DEFAULT_COLL
	def set_DEFAULT_COLL(self,DEFAULT_COLL):
		self.DEFAULT_COLL = DEFAULT_COLL
		return str("Se cambio dato por:\n{d}".format(d=str(self.DEFAULT_COLL)))
	
	def get_DEFAULT_DB(self):
		return self.DEFAULT_DB
	def set_DEFAULT_DB(self,DEFAULT_DB):
		self.DEFAULT_DB = DEFAULT_DB
		return str("Se cambio dato por:\n{d}".format(d=str(self.DEFAULT_DB)))


##ACTIONS

#DATABASE
	def read_database(self,database='default'):
		if database == 'default':
			database = self.DEFAULT_DB
		db_query = "select * from r where r.id = '{0}'".format(database)
		#db_query = "select {'web':r.['Web']} as bgh from r where r.id = '{0}'".format(DOCUMENTDB_DATABASE)
		db = list(self.CLIENT.QueryDatabases(db_query))[0]
		print ("DATABASE")
		print (db)
		db_link = db['_self']
		return db_link

	def create_database(self,ID_DB):
		self.DB = self.CLIENT.CreateDatabase({'id': ID_DB})
		return self.DB
#DATABASE

#COLLECTIONS___________________________________________________________________________
	def read_collection(self, col='default'):
		if col == 'default':
			col = self.DEFAULT_COLL
		DATABASE = self.read_database()
		collection_query = "select * from r where r.id = '{0}'".format(col)
		#coll_query = "select * from r"
		COLLECTION = list(self.CLIENT.QueryCollections(DATABASE, collection_query))[0]
		print ("COLLECTION")
		print (COLLECTION)
		COLLECTION_RES = COLLECTION['_self']
		return COLLECTION_RES

	def read_collections(self,db='default'):
		if db == 'default':
			db=self.DEFAULT_DB
		COLLECTIONS = list(self.CLIENT.ReadCollection(db))
		print ("COLLECTION")
		print (COLLECTIONS)
		COLLECTIONS_RES = COLLECTIONS['_self']
		return COLLECTIONS_RES

	def create_collection(self,DOCUMENTDB_COLLECTION):
		self.DB = self.CLIENT.ReadDatabase(self.DATABASE)
		options = {
    	'offerEnableRUPerMinuteThroughput': True,
    	'offerVersion': "V2"
    	#'offerThroughput': 400
		}
		COLLECTION = self.CLIENT.CreateCollection(self.DB['_self'], {'id': DOCUMENTDB_COLLECTION}, options)
		return COLLECTION

	def search_collection(self,db='default',co="default"):
		if db == 'default':
			db = self.DEFAULT_DB
		if co == 'default':
			co = self.DEFAULT_COLL
		DATABASE = self.read_database(db)
		collection_query = "select * from r where r.id = '{0}'".format(co)
		#coll_query = "select * from r"
		COLLECTION = list(self.CLIENT.QueryCollections(DATABASE, collection_query))[0]
		print ("COLLECTION")
		print (COLLECTION)
		COLLECTION_RES = COLLECTION['_self']
		return COLLECTION_RES

	def query_collection(self,db='default',co="default",qu="default",f="default"):
		if qu != "default":
			if db == 'default':
				db = self.DEFAULT_DB
			if co == 'default':
				co = self.DEFAULT_COLL
			DATABASE = self.read_database(db)
			if f=="default":
				collection_query = "select {q} from r where r.id = '{i}'".format(q=qu, i=co)
			else:
				collection_query = "select {q} from r where r.id = '{i}' and {f}".format(q=qu, i=co, f=f)
			#coll_query = "select * from r"
			COLLECTION = list(self.CLIENT.QueryCollections(DATABASE, collection_query))[0]
			print ("COLLECTION")
			print (COLLECTION)
			COLLECTION_RES = COLLECTION['_self']
			return COLLECTION_RES
		else:
			print("Not send query")
#COLLECTIONS___________________________________________________________________________
##DOCUMENTS_______________________________________________________________________
	def query_documents(self,col='default',query='default'):
		COLLECTION = self.read_collection()
		#docs_query = "select * from r"
		documents_query = str(query)
		DOCUMENTS_RES = list(self.CLIENT.QueryDocuments(COLLECTION, documents_query))
		print ("QUERY RESULTS")
		print(cc.SEP)
		print (str(DOCUMENTS_RES))
		len_documents_res = len(DOCUMENTS_RES)
		if int(len_documents_res) > 0:
			for item_docs in DOCUMENTS_RES:
				iidq = str(str(item_docs['id']).strip())
				if iidq != "":
					#print(item_docs)
					print(cc.SEP2)
					print("Item Id:\n"+str(item_docs['id'])+"\n\nItem Properties:\n"+str(item_docs))
					print(cc.SEP2)
		else:
			DOCUMENTS_RES = None
		print(cc.SEP)
		return DOCUMENTS_RES

	def search_docs(self,db='default',cid='default',col='default',field='default',full='default'):
		if db == 'default':
			db = self.DEFAULT_DB
		if col == 'default':
			col = self.DEFAULT_COLL
		path_db = 'dbs/LbNaAA==/'
		CLIENT2 = document_client.DocumentClient(self.ENDPOINT, {'masterKey': self.MASTERKEY})
		CLIENT2.ReadDatabase('dbs/LbNaAA==/')
		db_query = "select * from r where r.id = '{db}'".format(db=db)
		#db_query = "select * from r"
		dbresult = list(CLIENT2.QueryDatabases(db_query))[0]
		print ("DATABASES")
		print (dbresult)
		db_link = dbresult['_self']

	########################## Query a collection ####################
		coll_query = "select * from r where r.id = '{co}'".format(co=col)
	#coll_query = "select * from r"
		coll = list(CLIENT2.QueryCollections(db_link, coll_query))
		print ("COLLECTIONS")
		print (coll)

		coll_link = coll[0]['_self']

#SELECT VALUE COUNT(1) FROM c WHERE c.dataset_metadata_id = "oh_healthspace_food_service_facility_inspections"
		docs_query = "select * from c"
	#documents_query = str(query)
		try:
			docs = CLIENT2.QueryDocuments(coll_link, docs_query)
			print (len(list(docs)))
		except Exception as exsearch:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)
			print("Error Searching process: \nError:\n\t{e}\nArgs:\n\t{f}\nType:\n\t{t}\n\
				Info:\n\t{x}\nFName:\n\t{n}"\
				.format(e=str(exsearch),f=str(exsearch.args),t=str(type(exsearch)),\
					x=str(sys.exc_info()),n=str(fname)))
#st.styles("Type \n\t"+str(type(gral_exception)+"\n\nArgs: \n\t"+str(gral_exception.args)),"e")
		#st.styles("Error: \n\n"+str(gral_exception),"w")
		return list(docs)

	def search_documents(self,db='default',cid='default',col='default',filters='',filterf='',\
		join='',field='default',full='',value='',n_table='',query=''):
		if db == 'default':
			db = self.DEFAULT_DB
		if col == 'default':
			col = self.DEFAULT_COLL
		if field == 'default':
			field = "id"
		if n_table =='':
			n_table = 'r'
		client = document_client.DocumentClient(self.ENDPOINT, {'masterKey': self.MASTERKEY})
		client.ReadDatabase('dbs/LbNaAA==/')
		db_query = "select * from r where r.id = '{0}'".format(db)
		#db_query = "select * from r"
		db_result = list(client.QueryDatabases(db_query))[0]
		print ("DATABASES")
		print (db_result)
		db_link = db_result['_self']
		########################## Query a collection ####################
		coll_query = "select * from r where r.id = '{0}'".format(col)
		#coll_query = "select * from r"
		coll = list(client.QueryCollections(db_link, coll_query))
		print ("COLLECTIONS")
		print (coll)

		coll_link = coll[0]['_self']

	#SELECT VALUE COUNT(1) FROM c WHERE c.dataset_metadata_id = "oh_healthspace_food_service_facility_inspections"
		options = { 'enableCrossPartitionQuery': True }
		if query != '':
			docs_query = "{q}".format(q=query)
		else:
			if join != '':
				if filterf == '':
					if filters == '':
						docs_query = "select * from {n} JOIN {j}".format(n=n_table,j=join,f=field)
					else:
						docs_query = "select VALUE ({n}.{fs}) from {n} JOIN {j}".format(n=n_table,j=join,fs=filters,f=field)
				else:
					if filters == '':
						docs_query = "select * from {n} JOIN {j} where {f}".format(n=n_table,j=join,f=filterf)
					else:
						docs_query = "select {fs} from {n} JOIN {j} where {f}".format(n=n_table,j=join,f=filterf,fs=filters)
			else:
				if filterf == '':
					if filters == '':
						docs_query = "select * from {n}".format(n=n_table)
					else:
						docs_query = "select {fs} from {n}".format(n=n_table,fs=filters)
				else:
					if filters == '':
						docs_query = "select * from {n} where {f}".format(n=n_table,f=filterf)
					else:
						docs_query = "select {fs} from {n} where {f}".format(n=n_table,f=filterf,fs=filters)
		#documents_query = str(query)
		docs = client.QueryDocuments(coll_link, docs_query,options)
		#docs = client.ReadDocuments(coll_link)
		#print (list(docs))
		'''l_docs = []
		l_docs_m_id = docs
		for it_docs in docs:
			if it_docs'''
		print ("Results Documet query: "+str(len(list(docs))))
		return list(docs)
	def read_documents(self,field='default',ext1='default',ext2='default',col='default'):
		if col == 'default':
			col = self.COLLECTION
		#do_l = self.read_collection()
		#print(do_l[0]['id'])
		#COLLECTION = self.CLIENT.ReadCollection(self.COLLECTION)
		#docs_query = "select * from r"
		#self.DOCUMENTS = self.COLLECTION+ '/docs/'
		DOCUMENTS_RES= list(self.CLIENT.ReadDocuments(col))
		#coll_query = "select * from r"
		#self.CLIENT.ReadDocument(client,'SalesOrder1')
		len_documents_list = len(DOCUMENTS_RES)
		if int(len_documents_list) > 0:
			print("Results for Documents in {c}:\n\t{l}\n{s}\n".format(l=str(len_documents_list),c=str(self.COLLECTION),s=self.SEP))
			print(str(self.SEP))
			itera_l = 0
			for item_documents_list in DOCUMENTS_RES:
				if field != 'default':
					if ext1 != 'default':
						nfield = item_documents_list[field][ext1]
					else:
						nfield = item_documents_list[field]
				else:
					nfield = item_documents_list['id']
				itera_l += 1
				iird = str(str(item_documents_list['id']).strip())
				if iird != "":
					print("{s}{s}\nItem{co}: {name}\n{ss}\nItem ID:\n\t{id}\n{ss}\n".format(ss=self.SEP2,s=self.SEP,co=str(itera_l),id=str(item_documents_list['id']),\
							name=nfield))
					for k,v in item_documents_list.items():
						print("{k} : {v}\n".format(k=k,v=v,s=self.SEP2))
					print(self.SEP)
			
		else:
			DOCUMENTS_RES = None
		print(str(self.SEP))
		return DOCUMENTS_RES

	def update_document(self,iobject={},col=''):
		if col == '':
			COLLECTION = self.read_collection()
		else:
			COLLECTION = self.read_collection(col=col)
		self.CLIENT.UpsertDocument(COLLECTION,iobject)
		#self.cont_update_items += 1
		#print("Send Item: "+str(self.OBJECT)+" Update\nItem: "+str(self.cont_update_items))
		print("Updated:\n"+str(iobject))
		#print("READ.............................................DB")
		#self.read_documents(col=col)
		#print("READ..............................................END")
		
	def update_documents(self,l_objects=[],col=''):
		print("UPDATED MASIVE PROCESS")
		self.cont_update_items = 0
		def udoc(OBJ):
			if col == '':
				self.update_document(iobject=OBJ)
			else:
				self.update_document(iobject=OBJ,col=col)
		UPDATE_LIST_ITEMS = list(map(udoc, l_objects))
		print("len items update"+str(len(UPDATE_LIST_ITEMS)))
	def create_document(self,OBJECT):
		COLLECTION = read_collection()
		self.CLIENT.CreateDocument(COLLECTION,OBJECT)
		print("READ.............................................DB")
		self.read_documents()
		print("READ..............................................END")
	def dellete_document():
		pass
	def dellete_documents():
		pass
'''def __init__(self,connection="1"):
		self.cone = cc.config.it_con(self,connection)
		self.CLIENT = document_client.DocumentClient(cc.ENDPOINT, {'masterKey': cc.MASTERKEY})
		self.ID_COLLECTION = ID_COLLECTION
		self.DATABASE = 'dbs/'+str(self.ID_DATABASE)
		self.COLLECTION = self.DATABASE + '/colls/' + self.ID_COLLECTION'''

##DOCUMENTS_______________________________________________________________________


