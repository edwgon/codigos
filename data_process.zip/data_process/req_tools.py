import requests
import time
import sys



def region_request(url):
	free_service = '0'
	while free_service == '0':
		time.sleep(1)
		free_service = self.process_object['services_used']['healthspace']
	url_lower = url.lower()
	region = url_lower.split('ohio')[1].split('/')[1]
	#print("Region "+str(region))
	r_dict = {}
	time.sleep(1)
	try:
		s = requests.Session()
		r = s.get(url)
		#print(str(r.status_code))
	except:
		try:
			time.sleep(3)
			s = requests.Session()
			r = s.get(url)
		except:
			try:
				time.sleep(5)
				s = requests.Session()
				r = s.get(url)
			except:
				try:
					time.sleep(10)
					s = requests.Session()
					r = s.get(url)
				except:
					try:
						time.sleep(15)
						s = requests.Session()
						r = s.get(url)
					except:
						pass
	finally:
		r_dict.update({'r':r,'region':region})
		return r_dict


def general_request(url):
	#print(url)
	free_service = '0'
	while free_service == '0':
		time.sleep(1)
		free_service = self.process_object['services_used']['healthspace']
	try:
		time.sleep(3)
		s = requests.Session()
		r = s.get(url)
	except:
		try:
			#print("espera gral")
			time.sleep(5)
			r = requests.get(url)
		except:
			try: 
				#print("espera gral")
				time.sleep(10)
				r = requests.get(url)
			except:
				try:
					#print("espera gral")
					time.sleep(15)
					r = requests.get(url)
				except:
					pass
	finally:
		return r